import { Link } from "@tanstack/react-router";
import { Gamepad2, Home, Search, User } from "lucide-react";

const ITEMS = [
  { to: "/", label: "Home", icon: Home },
  { to: "/games", label: "Games", icon: Gamepad2 },
  { to: "/profile", label: "Profile", icon: User },
  { to: "/search", label: "Search", icon: Search },
] as const;

export function BottomNav() {
  return (
    <nav
      aria-label="Main"
      className="fixed inset-x-0 bottom-0 z-50 px-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] pt-2 md:bottom-4 md:pb-0"
    >
      <ul className="glass mx-auto grid max-w-md grid-cols-4 rounded-2xl p-1.5 shadow-card">
        {ITEMS.map(({ to, label, icon: Icon }) => (
          <li key={to}>
            <Link
              to={to}
              activeOptions={{ exact: to === "/" }}
              className="tap group flex flex-col items-center gap-1 rounded-xl py-2 text-[11px] font-semibold text-muted-foreground hover:text-foreground data-[status=active]:bg-elevated data-[status=active]:text-primary"
            >
              <Icon className="size-5 transition-transform group-hover:-translate-y-0.5 group-data-[status=active]:drop-shadow-[0_0_8px_var(--neon-cyan)]" />
              {label}
            </Link>
          </li>
        ))}
      </ul>
    </nav>
  );
}
