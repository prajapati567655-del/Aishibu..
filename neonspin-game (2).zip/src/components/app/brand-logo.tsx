import { Zap } from "lucide-react";
import { BRAND_NAME } from "@/lib/brand";

export function BrandLogo({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-2">
      <span className="grid size-9 place-items-center rounded-xl bg-gradient-neon text-primary-foreground shadow-glow-cyan">
        <Zap className="size-5 fill-current" />
      </span>
      {!compact && (
        <span className="font-display text-lg font-bold tracking-tight text-gradient-neon">{BRAND_NAME}</span>
      )}
    </div>
  );
}
