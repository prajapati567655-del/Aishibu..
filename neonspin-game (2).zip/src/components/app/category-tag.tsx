import type { GameCategory } from "@/lib/games";
import { cn } from "@/lib/utils";

const TONES: Record<GameCategory, string> = {
  Slots: "bg-neon-cyan/15 text-neon-cyan border-neon-cyan/30",
  Table: "bg-neon-purple/20 text-neon-purple border-neon-purple/40",
  Live: "bg-neon-orange/15 text-neon-orange border-neon-orange/30",
  Jackpots: "bg-neon-gold/15 text-neon-gold border-neon-gold/30",
};

export function CategoryTag({ category, className }: { category: GameCategory; className?: string }) {
  return (
    <span
      className={cn(
        "rounded-full border px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide backdrop-blur-md",
        TONES[category],
        className,
      )}
    >
      {category}
    </span>
  );
}
