import { Coins } from "lucide-react";
import { formatCoins } from "@/lib/games";
import { useWallet } from "./wallet";

export function CoinBadge() {
  const { coins } = useWallet();
  return (
    <div className="surface-elevated flex items-center gap-1.5 rounded-full py-1 pl-1 pr-3">
      <span className="grid size-7 place-items-center rounded-full bg-gradient-gold text-primary-foreground">
        <Coins className="size-4" />
      </span>
      <span className="font-display text-sm font-semibold tabular-nums text-neon-gold" aria-label="Coin balance">
        {formatCoins(coins)}
      </span>
    </div>
  );
}
