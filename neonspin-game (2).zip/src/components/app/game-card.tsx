import { Play, Users } from "lucide-react";
import { toast } from "sonner";
import type { Game } from "@/lib/games";
import { formatCoins } from "@/lib/games";
import { StarRating } from "./star-rating";
import { CategoryTag } from "./category-tag";

export function launchGame(game: Game) {
  toast.success(`Launching ${game.title}`, { description: "Demo mode · virtual coins only" });
}

export function GameCard({ game }: { game: Game }) {
  return (
    <button
      type="button"
      onClick={() => launchGame(game)}
      className="tap group surface relative overflow-hidden rounded-2xl text-left hover:-translate-y-1 hover:border-primary/40 hover:shadow-glow-cyan"
    >
      <div className="relative aspect-square overflow-hidden">
        <img
          src={game.image}
          alt={game.title}
          loading="lazy"
          width={640}
          height={640}
          className="size-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-card-fade" />
        <div className="absolute left-2 top-2 flex gap-1">
          {!(game.isLive && game.category === "Live") && <CategoryTag category={game.category} />}
          {game.isLive && (
            <span className="flex items-center gap-1 rounded-full bg-destructive px-2 py-0.5 text-[10px] font-bold uppercase text-destructive-foreground">
              <span className="animate-live size-1.5 rounded-full bg-destructive-foreground" /> Live
            </span>
          )}
        </div>
        <span className="absolute inset-0 m-auto grid size-12 scale-75 place-items-center rounded-full bg-gradient-neon text-primary-foreground opacity-0 shadow-glow-cyan transition-all group-hover:scale-100 group-hover:opacity-100">
          <Play className="size-5 fill-current" />
        </span>
      </div>
      <div className="space-y-1.5 p-3">
        <h3 className="truncate font-sans text-sm font-bold">{game.title}</h3>
        <div className="flex items-center justify-between gap-2">
          <StarRating value={game.rating} />
          <span className="flex items-center gap-1 text-[11px] text-muted-foreground">
            <Users className="size-3" /> {formatCoins(game.players)}
          </span>
        </div>
      </div>
    </button>
  );
}
