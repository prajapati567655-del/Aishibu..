import { Play } from "lucide-react";
import type { Game } from "@/lib/games";
import { Button } from "@/components/ui/button";
import { CategoryTag } from "./category-tag";
import { StarRating } from "./star-rating";
import { launchGame } from "./game-card";

export function GameRow({ game }: { game: Game }) {
  return (
    <li className="surface flex items-center gap-3 rounded-2xl p-2.5 transition-colors hover:border-primary/40 hover:bg-elevated">
      <img
        src={game.image}
        alt={game.title}
        loading="lazy"
        width={64}
        height={64}
        className="size-16 shrink-0 rounded-xl object-cover"
      />
      <div className="min-w-0 flex-1 space-y-1">
        <div className="flex items-center gap-2">
          <h3 className="truncate font-sans text-sm font-bold">{game.title}</h3>
        </div>
        <p className="truncate text-xs text-muted-foreground">{game.provider}</p>
        <div className="flex items-center gap-2">
          <CategoryTag category={game.category} />
          <StarRating value={game.rating} />
        </div>
      </div>
      <Button variant="neon" size="icon" className="size-10 shrink-0 rounded-full" aria-label={`Play ${game.title}`} onClick={() => launchGame(game)}>
        <Play className="fill-current" />
      </Button>
    </li>
  );
}
