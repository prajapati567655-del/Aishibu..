import type { ButtonHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

interface PillProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  active?: boolean;
}

export function Pill({ active = false, className, ...props }: PillProps) {
  return (
    <button
      type="button"
      aria-pressed={active}
      className={cn(
        "tap shrink-0 rounded-full border px-4 py-1.5 text-sm font-semibold",
        active
          ? "border-transparent bg-gradient-neon text-primary-foreground shadow-glow-cyan"
          : "border-border bg-card text-muted-foreground hover:border-primary/40 hover:text-foreground",
        className,
      )}
      {...props}
    />
  );
}
