import { useEffect, useRef, useState } from "react";
import { Minus, Plus, RotateCw, Trophy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { formatCoins } from "@/lib/games";
import { BET_STEPS, canSpin, evaluateSpin, randomGrid, stepBet, type Grid } from "@/lib/slot";
import { useWallet } from "./wallet";

const STOP_DELAYS = [700, 1000, 1300];

export function SlotMachine({ title, image }: { title: string; image: string }) {
  const { coins, adjustCoins } = useWallet();
  const [bet, setBet] = useState(50);
  const [grid, setGrid] = useState<Grid>(() => [
    ["🍋", "7️⃣", "🔔"],
    ["💎", "7️⃣", "🍒"],
    ["⭐", "7️⃣", "🍋"],
  ]);
  const [spinningReels, setSpinningReels] = useState<boolean[]>([false, false, false]);
  const [lastWin, setLastWin] = useState<number | null>(null);
  const timers = useRef<number[]>([]);
  const spinningRef = useRef<boolean[]>([false, false, false]);

  const spinning = spinningReels.some(Boolean);
  const affordable = canSpin(coins, bet);

  useEffect(() => () => timers.current.forEach((t) => window.clearTimeout(t)), []);

  function spin() {
    if (spinning || !affordable) return;
    adjustCoins(-bet);
    setLastWin(null);
    const final = randomGrid();
    spinningRef.current = [true, true, true];
    setSpinningReels([true, true, true]);

    const shuffle = window.setInterval(() => {
      setGrid((g) => {
        const r = randomGrid();
        return g.map((reel, i) => (spinningRef.current[i] ? (r[i] as Grid[number]) : reel));
      });
    }, 80);

    STOP_DELAYS.forEach((delay, i) => {
      timers.current.push(
        window.setTimeout(() => {
          spinningRef.current[i] = false;
          setGrid((g) => g.map((reel, j) => (j === i ? (final[i] as Grid[number]) : reel)));
          setSpinningReels((s) => s.map((v, j) => (j === i ? false : v)));
          if (i === STOP_DELAYS.length - 1) {
            window.clearInterval(shuffle);
            const win = evaluateSpin(final, bet);
            setLastWin(win);
            if (win > 0) adjustCoins(win);
          }
        }, delay),
      );
    });
  }

  const won = lastWin !== null && lastWin > 0;

  return (
    <section className="surface overflow-hidden rounded-3xl">
      <div className="flex items-center gap-3 border-b border-border p-4">
        <img src={image} alt="" width={48} height={48} className="size-12 rounded-xl object-cover" />
        <div className="min-w-0 flex-1">
          <p className="text-[11px] font-bold uppercase tracking-widest text-neon-purple">Demo preview</p>
          <h3 className="truncate text-base font-semibold">{title}</h3>
        </div>
        <div className="text-right">
          <p className="text-[11px] font-semibold uppercase text-muted-foreground">Balance</p>
          <p className="font-display text-sm font-semibold tabular-nums text-neon-gold" data-testid="slot-balance">
            {formatCoins(coins)}
          </p>
        </div>
      </div>

      <div className="p-4">
        <div className="relative rounded-2xl bg-background p-2 shadow-glow-purple">
          <div className="grid grid-cols-3 gap-2">
            {grid.map((reel, i) => (
              <div key={i} className="overflow-hidden rounded-xl bg-elevated">
                {reel.map((sym, row) => (
                  <div
                    key={row}
                    className={cn(
                      "grid h-16 place-items-center text-3xl sm:h-20 sm:text-4xl",
                      row !== 1 && "opacity-40",
                      spinningReels[i] && "animate-reel",
                    )}
                  >
                    {sym}
                  </div>
                ))}
              </div>
            ))}
          </div>
          {/* Win line */}
          <div
            aria-hidden
            className={cn(
              "pointer-events-none absolute inset-x-1 top-1/2 h-0.5 -translate-y-1/2 rounded-full",
              won ? "animate-win bg-neon-gold" : "bg-neon-cyan/50",
            )}
          />
          <span className="absolute -left-1 top-1/2 size-3 -translate-y-1/2 rounded-full bg-neon-cyan shadow-glow-cyan" />
          <span className="absolute -right-1 top-1/2 size-3 -translate-y-1/2 rounded-full bg-neon-cyan shadow-glow-cyan" />
        </div>

        <div className="mt-3 flex h-8 items-center justify-center text-sm font-semibold" aria-live="polite">
          {spinning && <span className="text-muted-foreground">Spinning…</span>}
          {!spinning && won && (
            <span className="flex items-center gap-1.5 text-gradient-gold font-display text-base">
              <Trophy className="size-4 text-neon-gold" /> You won {formatCoins(lastWin ?? 0)} coins!
            </span>
          )}
          {!spinning && lastWin === 0 && <span className="text-muted-foreground">No win this time — spin again</span>}
          {!spinning && lastWin === null && (
            <span className="text-muted-foreground">Match 3 on the glowing line to win</span>
          )}
        </div>

        <div className="mt-2 flex items-center gap-3">
          <div className="surface-elevated flex items-center gap-1 rounded-xl p-1">
            <Button
              variant="ghost"
              size="icon"
              aria-label="Lower bet"
              disabled={spinning || bet === BET_STEPS[0]}
              onClick={() => setBet((b) => stepBet(b, -1))}
            >
              <Minus />
            </Button>
            <div className="w-16 text-center">
              <p className="text-[10px] font-semibold uppercase text-muted-foreground">Bet</p>
              <p className="font-display text-sm font-semibold tabular-nums" data-testid="slot-bet">
                {bet}
              </p>
            </div>
            <Button
              variant="ghost"
              size="icon"
              aria-label="Raise bet"
              disabled={spinning || bet === BET_STEPS[BET_STEPS.length - 1]}
              onClick={() => setBet((b) => stepBet(b, 1))}
            >
              <Plus />
            </Button>
          </div>
          <Button variant="gold" size="xl" className="flex-1" onClick={spin} disabled={spinning || !affordable}>
            <RotateCw className={cn(spinning && "animate-spin")} />
            {affordable ? "Spin" : "Not enough coins"}
          </Button>
        </div>
      </div>
    </section>
  );
}
