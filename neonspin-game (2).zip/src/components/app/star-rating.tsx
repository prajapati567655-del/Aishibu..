import { Star } from "lucide-react";

export function StarRating({ value }: { value: number }) {
  return (
    <div className="flex items-center gap-1" aria-label={`Rated ${value} out of 5`}>
      <div className="flex">
        {Array.from({ length: 5 }, (_, i) => (
          <Star
            key={i}
            className={
              i < Math.round(value) ? "size-3 fill-neon-gold text-neon-gold" : "size-3 text-muted-foreground/40"
            }
          />
        ))}
      </div>
      <span className="text-xs font-semibold text-muted-foreground">{value.toFixed(1)}</span>
    </div>
  );
}
