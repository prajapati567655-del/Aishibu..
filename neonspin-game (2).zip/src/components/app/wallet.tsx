import { createContext, useContext, useMemo, useState, type ReactNode } from "react";

export const USER = {
  displayName: "Alex Rivera",
  username: "@neon_alex",
  level: 12,
  xp: 3420,
  xpToNext: 5000,
  initials: "AR",
};

interface WalletState {
  coins: number;
  bonus: number;
  adjustCoins: (delta: number) => void;
}

const WalletContext = createContext<WalletState | null>(null);

export function WalletProvider({ children }: { children: ReactNode }) {
  const [coins, setCoins] = useState(12_450);
  const value = useMemo(
    () => ({ coins, bonus: 2_500, adjustCoins: (d: number) => setCoins((c) => Math.max(0, c + d)) }),
    [coins],
  );
  return <WalletContext.Provider value={value}>{children}</WalletContext.Provider>;
}

export function useWallet() {
  const ctx = useContext(WalletContext);
  if (!ctx) throw new Error("useWallet must be used inside WalletProvider");
  return ctx;
}
