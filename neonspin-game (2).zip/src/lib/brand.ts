export const BRAND_NAME = "NeonSpin";
