import pharaoh from "@/assets/game-pharaoh.jpg";
import dragon from "@/assets/game-dragon.jpg";
import roulette from "@/assets/game-roulette.jpg";
import fruits from "@/assets/game-fruits.jpg";
import blackjack from "@/assets/game-blackjack.jpg";
import cosmic from "@/assets/game-cosmic.jpg";

export type GameCategory = "Slots" | "Table" | "Live" | "Jackpots";

export interface Game {
  id: string;
  title: string;
  provider: string;
  category: GameCategory;
  tags: string[];
  rating: number;
  players: number;
  image: string;
  isNew: boolean;
  isLive: boolean;
  popular: boolean;
}

export const GAMES: Game[] = [
  { id: "pharaoh-gold", title: "Pharaoh's Gold", provider: "Nile Studios", category: "Slots", tags: ["Egypt", "Bonus Buy"], rating: 4.8, players: 2341, image: pharaoh, isNew: false, isLive: false, popular: true },
  { id: "crystal-dragon", title: "Crystal Dragon", provider: "Mythic Labs", category: "Jackpots", tags: ["Fantasy", "Megaways"], rating: 4.7, players: 1876, image: dragon, isNew: true, isLive: false, popular: true },
  { id: "neon-roulette", title: "Neon Roulette", provider: "Pulse Live", category: "Live", tags: ["Classic", "Live Dealer"], rating: 4.6, players: 982, image: roulette, isNew: false, isLive: true, popular: true },
  { id: "retro-fruits", title: "Retro Fruits 777", provider: "Synthwave Co.", category: "Slots", tags: ["Classic", "Fruits"], rating: 4.5, players: 1520, image: fruits, isNew: true, isLive: false, popular: false },
  { id: "vip-blackjack", title: "VIP Blackjack", provider: "Pulse Live", category: "Table", tags: ["Cards", "Live Dealer"], rating: 4.9, players: 640, image: blackjack, isNew: false, isLive: true, popular: true },
  { id: "cosmic-rocket", title: "Cosmic Rocket", provider: "Orbit Games", category: "Jackpots", tags: ["Space", "Crash"], rating: 4.4, players: 3105, image: cosmic, isNew: true, isLive: false, popular: false },
  { id: "pharaoh-tomb", title: "Tomb of Ra", provider: "Nile Studios", category: "Slots", tags: ["Egypt", "Free Spins"], rating: 4.3, players: 712, image: pharaoh, isNew: true, isLive: false, popular: false },
  { id: "dragon-baccarat", title: "Dragon Baccarat", provider: "Mythic Labs", category: "Table", tags: ["Cards", "Fantasy"], rating: 4.2, players: 455, image: dragon, isNew: false, isLive: false, popular: false },
  { id: "lightning-wheel", title: "Lightning Wheel", provider: "Pulse Live", category: "Live", tags: ["Game Show", "Live Dealer"], rating: 4.7, players: 2210, image: roulette, isNew: true, isLive: true, popular: true },
  { id: "cherry-blast", title: "Cherry Blast", provider: "Synthwave Co.", category: "Slots", tags: ["Fruits", "Free Spins"], rating: 4.1, players: 388, image: fruits, isNew: false, isLive: false, popular: false },
  { id: "galaxy-jackpot", title: "Galaxy Jackpot", provider: "Orbit Games", category: "Jackpots", tags: ["Space", "Megaways"], rating: 4.6, players: 1290, image: cosmic, isNew: false, isLive: false, popular: true },
  { id: "high-roller-poker", title: "High Roller Poker", provider: "Pulse Live", category: "Table", tags: ["Cards", "Classic"], rating: 4.5, players: 870, image: blackjack, isNew: false, isLive: true, popular: false },
];

export const CATEGORIES: { name: GameCategory; tone: "cyan" | "purple" | "gold" | "orange" }[] = [
  { name: "Slots", tone: "cyan" },
  { name: "Table", tone: "purple" },
  { name: "Live", tone: "orange" },
  { name: "Jackpots", tone: "gold" },
];

export const SUGGESTED_TAGS = ["Megaways", "Live Dealer", "Free Spins", "Egypt", "Space", "Cards", "Fruits", "Classic"];

export type HomeTab = "Popular" | "New" | "Live";
export type LobbyFilter = "All" | "Slots" | "Live" | "New";

export function countByCategory(games: Game[], category: GameCategory): number {
  return games.filter((g) => g.category === category).length;
}

export function gamesForHomeTab(games: Game[], tab: HomeTab): Game[] {
  if (tab === "New") return games.filter((g) => g.isNew);
  if (tab === "Live") return games.filter((g) => g.isLive);
  return games.filter((g) => g.popular).sort((a, b) => b.players - a.players);
}

export function gamesForLobbyFilter(games: Game[], filter: LobbyFilter): Game[] {
  if (filter === "Slots") return games.filter((g) => g.category === "Slots");
  if (filter === "Live") return games.filter((g) => g.isLive);
  if (filter === "New") return games.filter((g) => g.isNew);
  return games;
}

/** Matches title, provider, category or any tag (case-insensitive). Selected tags must all match. */
export function searchGames(games: Game[], query: string, tags: string[] = []): Game[] {
  const q = query.trim().toLowerCase();
  return games.filter((g) => {
    const matchesQuery =
      q === "" ||
      g.title.toLowerCase().includes(q) ||
      g.provider.toLowerCase().includes(q) ||
      g.category.toLowerCase().includes(q) ||
      g.tags.some((t) => t.toLowerCase().includes(q));
    const matchesTags = tags.every((t) => g.tags.includes(t));
    return matchesQuery && matchesTags;
  });
}

export const formatCoins = (n: number) => new Intl.NumberFormat("en-US").format(n);
