export const SYMBOLS = ["🍒", "🍋", "🔔", "💎", "7️⃣", "⭐"] as const;
export type SlotSymbol = (typeof SYMBOLS)[number];

/** Payout multiplier for three matching symbols on the center line. */
export const PAYOUTS: Record<SlotSymbol, number> = {
  "🍒": 2,
  "🍋": 3,
  "🔔": 5,
  "⭐": 8,
  "💎": 15,
  "7️⃣": 25,
};

export const BET_STEPS = [10, 25, 50, 100, 250, 500];

/** 3 reels x 3 rows; row index 1 is the win line. */
export type Grid = SlotSymbol[][];

export function randomGrid(rand: () => number = Math.random): Grid {
  return Array.from({ length: 3 }, () =>
    Array.from({ length: 3 }, () => SYMBOLS[Math.floor(rand() * SYMBOLS.length)] as SlotSymbol),
  );
}

export function centerLine(grid: Grid): SlotSymbol[] {
  return grid.map((reel) => reel[1] as SlotSymbol);
}

/** Three of a kind on the center line pays bet x multiplier; two cherries from the left return the bet. */
export function evaluateSpin(grid: Grid, bet: number): number {
  const [a, b, c] = centerLine(grid);
  if (a === b && b === c && a) return bet * PAYOUTS[a];
  if (a === "🍒" && b === "🍒") return bet;
  return 0;
}

export function canSpin(balance: number, bet: number): boolean {
  return bet > 0 && balance >= bet;
}

export function stepBet(current: number, dir: 1 | -1): number {
  const i = BET_STEPS.indexOf(current);
  const next = Math.min(BET_STEPS.length - 1, Math.max(0, (i === -1 ? 0 : i) + dir));
  return BET_STEPS[next] as number;
}
