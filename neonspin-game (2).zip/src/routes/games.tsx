import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Crown, Dices, Radio, Search, Spade } from "lucide-react";
import pharaoh from "@/assets/game-pharaoh.jpg";
import { CoinBadge } from "@/components/app/coin-badge";
import { GameCard } from "@/components/app/game-card";
import { PageShell, SectionTitle } from "@/components/app/page-shell";
import { Pill } from "@/components/app/pill";
import { SlotMachine } from "@/components/app/slot-machine";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import {
  CATEGORIES,
  GAMES,
  countByCategory,
  gamesForLobbyFilter,
  searchGames,
  type GameCategory,
  type LobbyFilter,
} from "@/lib/games";

export const Route = createFileRoute("/games")({
  head: () => ({
    meta: [
      { title: "Games Lobby — NeonSpin" },
      { name: "description", content: "Browse slots, table games, live dealers and jackpots, and try a demo spin." },
      { property: "og:title", content: "Games Lobby — NeonSpin" },
      { property: "og:description", content: "Browse slots, table games, live dealers and jackpots, and try a demo spin." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: GamesPage,
});

const ICONS: Record<GameCategory, typeof Dices> = { Slots: Dices, Table: Spade, Live: Radio, Jackpots: Crown };
const TILE_TONES = {
  cyan: "text-neon-cyan bg-neon-cyan/12 hover:shadow-glow-cyan",
  purple: "text-neon-purple bg-neon-purple/15 hover:shadow-glow-purple",
  orange: "text-neon-orange bg-neon-orange/12 hover:shadow-glow-gold",
  gold: "text-neon-gold bg-neon-gold/12 hover:shadow-glow-gold",
} as const;
const FILTERS: LobbyFilter[] = ["All", "Slots", "Live", "New"];

function GamesPage() {
  const [filter, setFilter] = useState<LobbyFilter>("All");
  const [query, setQuery] = useState("");
  const games = searchGames(gamesForLobbyFilter(GAMES, filter), query);

  return (
    <PageShell>
      <header className="flex items-center justify-between gap-3">
        <div>
          <p className="text-xs font-semibold uppercase tracking-widest text-neon-cyan">Lobby</p>
          <h1 className="text-xl font-bold sm:text-2xl">Games</h1>
        </div>
        <CoinBadge />
      </header>

      <div className="mt-5 grid grid-cols-4 gap-2 sm:gap-3">
        {CATEGORIES.map(({ name, tone }) => {
          const Icon = ICONS[name];
          return (
            <button
              key={name}
              type="button"
              onClick={() => setFilter(name === "Slots" ? "Slots" : name === "Live" ? "Live" : "All")}
              className="tap surface flex flex-col items-center gap-2 rounded-2xl px-1 py-3 hover:-translate-y-0.5 sm:py-4"
            >
              <span className={cn("grid size-10 place-items-center rounded-xl transition-shadow sm:size-12", TILE_TONES[tone])}>
                <Icon className="size-5 sm:size-6" />
              </span>
              <span className="text-xs font-bold sm:text-sm">{name}</span>
              <span className="text-[10px] font-semibold text-muted-foreground sm:text-xs">
                {countByCategory(GAMES, name)} games
              </span>
            </button>
          );
        })}
      </div>

      <div className="mt-5 grid gap-6 lg:grid-cols-[380px_1fr]">
        <div className="lg:sticky lg:top-6 lg:self-start">
          <SlotMachine title="Pharaoh's Gold" image={pharaoh} />
        </div>

        <div>
          <div className="relative">
            <Search className="pointer-events-none absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search the lobby"
              aria-label="Search the lobby"
              className="h-11 rounded-xl border-border bg-card pl-10 text-sm"
            />
          </div>
          <div className="no-scrollbar -mx-4 mt-3 flex gap-2 overflow-x-auto px-4 sm:mx-0 sm:px-0">
            {FILTERS.map((f) => (
              <Pill key={f} active={filter === f} onClick={() => setFilter(f)}>
                {f}
              </Pill>
            ))}
          </div>

          <div className="mt-5">
            <SectionTitle action={<span className="text-xs text-muted-foreground">{games.length} games</span>}>
              {filter === "All" ? "All games" : `${filter} games`}
            </SectionTitle>
            {games.length === 0 ? (
              <p className="surface rounded-2xl p-6 text-center text-sm text-muted-foreground">
                No games match “{query}”.
              </p>
            ) : (
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4">
                {games.map((g) => (
                  <GameCard key={g.id} game={g} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </PageShell>
  );
}
