import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Bell, Flame, Gift, Radio, Sparkles } from "lucide-react";
import banner from "@/assets/banner-welcome.jpg";
import { BrandLogo } from "@/components/app/brand-logo";
import { CoinBadge } from "@/components/app/coin-badge";
import { GameCard } from "@/components/app/game-card";
import { PageShell, SectionTitle } from "@/components/app/page-shell";
import { Pill } from "@/components/app/pill";
import { USER } from "@/components/app/wallet";
import { Button } from "@/components/ui/button";
import { GAMES, gamesForHomeTab, type HomeTab } from "@/lib/games";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "NeonSpin — Home" },
      { name: "description", content: "Featured neon slots, new releases and live tables, all with virtual coins." },
      { property: "og:title", content: "NeonSpin — Home" },
      { property: "og:description", content: "Featured neon slots, new releases and live tables, all with virtual coins." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const TABS: { name: HomeTab; icon: typeof Flame }[] = [
  { name: "Popular", icon: Flame },
  { name: "New", icon: Sparkles },
  { name: "Live", icon: Radio },
];

function Index() {
  const [tab, setTab] = useState<HomeTab>("Popular");
  const games = gamesForHomeTab(GAMES, tab);

  return (
    <PageShell>
      <header className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <BrandLogo compact />
          <div className="leading-tight">
            <p className="text-xs text-muted-foreground">Welcome back</p>
            <p className="font-display text-sm font-semibold">{USER.displayName}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <CoinBadge />
          <Button variant="glass" size="icon" className="rounded-full" aria-label="Notifications">
            <Bell />
          </Button>
        </div>
      </header>

      <section className="relative mt-5 overflow-hidden rounded-3xl border border-border shadow-glow-purple">
        <img
          src={banner}
          alt="Glowing slot reels with gold coins"
          width={1400}
          height={788}
          className="absolute inset-0 size-full object-cover object-right"
        />
        <div className="absolute inset-0 bg-gradient-banner" />
        <div className="relative max-w-md space-y-3 p-5 py-8 sm:p-8 sm:py-12">
          <span className="inline-flex items-center gap-1.5 rounded-full border border-neon-gold/40 bg-neon-gold/15 px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-neon-gold">
            <Gift className="size-3.5" /> Welcome bonus
          </span>
          <h1 className="text-2xl font-bold leading-tight sm:text-4xl">
            Spin into <span className="text-gradient-neon">5,000</span> free coins
          </h1>
          <p className="text-sm text-muted-foreground sm:text-base">
            Claim your daily drop and try any game in demo mode.
          </p>
          <Button variant="neon" size="xl" asChild>
            <Link to="/games">Claim &amp; play</Link>
          </Button>
        </div>
      </section>

      <section className="mt-7">
        <div className="no-scrollbar -mx-4 mb-4 flex gap-2 overflow-x-auto px-4 sm:mx-0 sm:px-0" role="tablist">
          {TABS.map(({ name, icon: Icon }) => (
            <Pill key={name} role="tab" aria-selected={tab === name} active={tab === name} onClick={() => setTab(name)}>
              <span className="flex items-center gap-1.5">
                <Icon className="size-4" /> {name}
              </span>
            </Pill>
          ))}
        </div>
        <SectionTitle
          action={
            <Link to="/games" className="text-sm font-semibold text-primary hover:underline">
              See all
            </Link>
          }
        >
          {tab} games
        </SectionTitle>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 lg:grid-cols-4">
          {games.map((g) => (
            <GameCard key={g.id} game={g} />
          ))}
        </div>
      </section>
    </PageShell>
  );
}
