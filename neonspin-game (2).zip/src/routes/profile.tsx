import { createFileRoute } from "@tanstack/react-router";
import { useState, type ReactNode } from "react";
import {
  ArrowDownToLine,
  ArrowUpFromLine,
  ChevronRight,
  Coins,
  Gift,
  Headphones,
  History,
  MessageSquare,
  Settings,
  ShieldCheck,
} from "lucide-react";
import { toast } from "sonner";
import { PageShell, SectionTitle } from "@/components/app/page-shell";
import { USER, useWallet } from "@/components/app/wallet";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";
import { formatCoins } from "@/lib/games";

export const Route = createFileRoute("/profile")({
  head: () => ({
    meta: [
      { title: "My Profile — NeonSpin" },
      { name: "description", content: "Your level, virtual coin balances, bonuses, security and account settings." },
      { property: "og:title", content: "My Profile — NeonSpin" },
      { property: "og:description", content: "Your level, virtual coin balances, bonuses, security and account settings." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ProfilePage,
});

const TRANSACTIONS = [
  { id: 1, label: "Win · Pharaoh's Gold", date: "Today, 14:12", amount: 1250 },
  { id: 2, label: "Coin pack deposit", date: "Today, 09:40", amount: 5000 },
  { id: 3, label: "Bet · Neon Roulette", date: "Yesterday", amount: -400 },
  { id: 4, label: "Daily bonus", date: "Nov 22", amount: 500 },
];

const BONUSES = [
  { id: 1, name: "50 Free Spins", detail: "Crystal Dragon · expires in 2 days", progress: 60 },
  { id: 2, name: "Weekend Cashback 10%", detail: "Up to 2,000 coins · ends Sunday", progress: 25 },
];

const SECURITY = [
  { id: "2fa", label: "Two-factor sign-in", defaultOn: true },
  { id: "bio", label: "Face / fingerprint unlock", defaultOn: false },
  { id: "alerts", label: "New device alerts", defaultOn: true },
];

function ProfilePage() {
  const { coins, bonus, adjustCoins } = useWallet();
  const [open, setOpen] = useState<string | null>("history");
  const pct = Math.round((USER.xp / USER.xpToNext) * 100);
  const toggle = (id: string) => setOpen((o) => (o === id ? null : id));

  return (
    <PageShell>
      <header className="flex items-center justify-between">
        <h1 className="text-xl font-bold sm:text-2xl">Profile</h1>
        <Button variant="glass" size="icon" className="rounded-full" aria-label="Settings">
          <Settings />
        </Button>
      </header>

      <div className="mt-5 grid gap-5 lg:grid-cols-[380px_1fr]">
        <div className="space-y-5">
          <section className="surface relative overflow-hidden rounded-3xl p-5">
            <div className="absolute -right-16 -top-16 size-48 rounded-full bg-neon-purple/25 blur-3xl" />
            <div className="relative flex items-center gap-4">
              <div className="rounded-full bg-gradient-neon p-0.5 shadow-glow-purple">
                <div className="grid size-16 place-items-center rounded-full bg-card font-display text-xl font-bold">
                  {USER.initials}
                </div>
              </div>
              <div className="min-w-0">
                <p className="truncate font-display text-lg font-semibold">{USER.displayName}</p>
                <p className="text-sm text-muted-foreground">{USER.username}</p>
              </div>
              <span className="ml-auto rounded-full bg-gradient-gold px-3 py-1 font-display text-xs font-bold text-primary-foreground">
                LVL {USER.level}
              </span>
            </div>
            <div className="relative mt-5">
              <div className="mb-1.5 flex justify-between text-xs font-semibold">
                <span className="text-muted-foreground">Level {USER.level + 1} progress</span>
                <span className="text-neon-cyan">
                  {formatCoins(USER.xp)} / {formatCoins(USER.xpToNext)} XP
                </span>
              </div>
              <Progress value={pct} className="h-2.5 bg-elevated" aria-label="Level progress" />
            </div>

            <div className="relative mt-5 grid grid-cols-2 gap-3">
              <Balance label="Virtual cash" value={coins} icon={<Coins className="size-4" />} tone="gold" />
              <Balance label="Bonus" value={bonus} icon={<Gift className="size-4" />} tone="purple" />
            </div>
          </section>

          <section className="grid grid-cols-3 gap-3">
            <QuickAction
              label="Deposit"
              icon={<ArrowDownToLine />}
              tone="cyan"
              onClick={() => {
                adjustCoins(1000);
                toast.success("1,000 virtual coins added");
              }}
            />
            <QuickAction
              label="Withdraw"
              icon={<ArrowUpFromLine />}
              tone="orange"
              onClick={() => toast("Withdrawals are disabled in demo mode")}
            />
            <QuickAction
              label="Messages"
              icon={<MessageSquare />}
              tone="purple"
              badge={3}
              onClick={() => toast("You have 3 unread messages")}
            />
          </section>
        </div>

        <section>
          <SectionTitle>Account</SectionTitle>
          <div className="surface divide-y divide-border overflow-hidden rounded-3xl">
            <Row id="history" icon={<History />} label="Transaction history" hint={`${TRANSACTIONS.length} recent`} open={open} onToggle={toggle}>
              <ul className="space-y-2">
                {TRANSACTIONS.map((t) => (
                  <li key={t.id} className="flex items-center justify-between rounded-xl bg-background/60 px-3 py-2.5">
                    <div>
                      <p className="text-sm font-semibold">{t.label}</p>
                      <p className="text-xs text-muted-foreground">{t.date}</p>
                    </div>
                    <span className={cn("font-display text-sm font-semibold tabular-nums", t.amount > 0 ? "text-neon-green" : "text-neon-orange")}>
                      {t.amount > 0 ? "+" : "−"}
                      {formatCoins(Math.abs(t.amount))}
                    </span>
                  </li>
                ))}
              </ul>
            </Row>
            <Row id="bonuses" icon={<Gift />} label="Active bonuses" hint={`${BONUSES.length} active`} open={open} onToggle={toggle}>
              <ul className="space-y-2">
                {BONUSES.map((b) => (
                  <li key={b.id} className="rounded-xl bg-background/60 p-3">
                    <p className="text-sm font-semibold">{b.name}</p>
                    <p className="mb-2 text-xs text-muted-foreground">{b.detail}</p>
                    <Progress value={b.progress} className="h-1.5 bg-elevated" aria-label={`${b.name} progress`} />
                  </li>
                ))}
              </ul>
            </Row>
            <Row id="security" icon={<ShieldCheck />} label="Security" hint="2 of 3 on" open={open} onToggle={toggle}>
              <ul className="space-y-1">
                {SECURITY.map((s) => (
                  <li key={s.id} className="flex items-center justify-between rounded-xl px-3 py-2.5 hover:bg-background/60">
                    <label htmlFor={s.id} className="text-sm font-semibold">
                      {s.label}
                    </label>
                    <Switch id={s.id} defaultChecked={s.defaultOn} />
                  </li>
                ))}
              </ul>
            </Row>
            <Row id="support" icon={<Headphones />} label="Account support" hint="24/7 chat" open={open} onToggle={toggle}>
              <div className="flex flex-col gap-2 sm:flex-row">
                <Button variant="neon" className="flex-1" onClick={() => toast("Connecting you to support…")}>
                  Start live chat
                </Button>
                <Button variant="glass" className="flex-1" onClick={() => toast("Opening help center")}>
                  Help center
                </Button>
              </div>
            </Row>
          </div>
        </section>
      </div>
    </PageShell>
  );
}

const TONE_TEXT = {
  cyan: "text-neon-cyan bg-neon-cyan/12",
  purple: "text-neon-purple bg-neon-purple/15",
  gold: "text-neon-gold bg-neon-gold/12",
  orange: "text-neon-orange bg-neon-orange/12",
} as const;

function Balance({ label, value, icon, tone }: { label: string; value: number; icon: ReactNode; tone: keyof typeof TONE_TEXT }) {
  return (
    <div className="surface-elevated rounded-2xl p-3">
      <div className="flex items-center gap-2 text-xs font-semibold text-muted-foreground">
        <span className={cn("grid size-6 place-items-center rounded-lg", TONE_TEXT[tone])}>{icon}</span>
        {label}
      </div>
      <p className={cn("mt-2 font-display text-lg font-semibold tabular-nums", tone === "gold" ? "text-neon-gold" : "text-neon-purple")}>
        {formatCoins(value)}
      </p>
    </div>
  );
}

function QuickAction({
  label,
  icon,
  tone,
  badge,
  onClick,
}: {
  label: string;
  icon: ReactNode;
  tone: keyof typeof TONE_TEXT;
  badge?: number;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="tap surface relative flex flex-col items-center gap-2 rounded-2xl py-4 hover:-translate-y-0.5 hover:border-primary/40"
    >
      <span className={cn("grid size-11 place-items-center rounded-xl [&_svg]:size-5", TONE_TEXT[tone])}>{icon}</span>
      <span className="text-xs font-bold">{label}</span>
      {badge ? (
        <span className="absolute right-3 top-3 grid size-5 place-items-center rounded-full bg-neon-orange text-[10px] font-bold text-primary-foreground">
          {badge}
        </span>
      ) : null}
    </button>
  );
}

function Row({
  id,
  icon,
  label,
  hint,
  open,
  onToggle,
  children,
}: {
  id: string;
  icon: ReactNode;
  label: string;
  hint: string;
  open: string | null;
  onToggle: (id: string) => void;
  children: ReactNode;
}) {
  const isOpen = open === id;
  return (
    <div>
      <button
        type="button"
        aria-expanded={isOpen}
        onClick={() => onToggle(id)}
        className="flex w-full items-center gap-3 px-4 py-4 text-left transition-colors hover:bg-elevated"
      >
        <span className="grid size-9 place-items-center rounded-xl bg-elevated text-primary [&_svg]:size-4">{icon}</span>
        <span className="flex-1 text-sm font-bold">{label}</span>
        <span className="text-xs text-muted-foreground">{hint}</span>
        <ChevronRight className={cn("size-4 text-muted-foreground transition-transform", isOpen && "rotate-90")} />
      </button>
      {isOpen && <div className="animate-in fade-in slide-in-from-top-1 px-4 pb-4">{children}</div>}
    </div>
  );
}
