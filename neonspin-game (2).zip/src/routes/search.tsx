import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Search, X } from "lucide-react";
import { GameRow } from "@/components/app/game-row";
import { PageShell, SectionTitle } from "@/components/app/page-shell";
import { Pill } from "@/components/app/pill";
import { Input } from "@/components/ui/input";
import { GAMES, SUGGESTED_TAGS, searchGames } from "@/lib/games";

export const Route = createFileRoute("/search")({
  head: () => ({
    meta: [
      { title: "Search Games — NeonSpin" },
      { name: "description", content: "Find any slot, table or live game instantly by name, provider or tag." },
      { property: "og:title", content: "Search Games — NeonSpin" },
      { property: "og:description", content: "Find any slot, table or live game instantly by name, provider or tag." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: SearchPage,
});

function SearchPage() {
  const [query, setQuery] = useState("");
  const [tags, setTags] = useState<string[]>([]);
  const results = searchGames(GAMES, query, tags);
  const toggleTag = (t: string) => setTags((cur) => (cur.includes(t) ? cur.filter((x) => x !== t) : [...cur, t]));

  return (
    <PageShell>
      <h1 className="text-xl font-bold sm:text-2xl">Search</h1>
      <div className="relative mt-4">
        <Search className="pointer-events-none absolute left-4 top-1/2 size-5 -translate-y-1/2 text-primary" />
        <Input
          autoFocus
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Games, providers, themes…"
          aria-label="Search games"
          className="h-13 rounded-2xl border-primary/30 bg-card pl-12 pr-11 text-base shadow-glow-cyan focus-visible:ring-primary"
        />
        {query && (
          <button
            type="button"
            aria-label="Clear search"
            onClick={() => setQuery("")}
            className="tap absolute right-3 top-1/2 grid size-7 -translate-y-1/2 place-items-center rounded-full bg-elevated text-muted-foreground hover:text-foreground"
          >
            <X className="size-4" />
          </button>
        )}
      </div>

      <div className="mt-4">
        <p className="mb-2 text-xs font-semibold uppercase tracking-widest text-muted-foreground">Suggested</p>
        <div className="flex flex-wrap gap-2">
          {SUGGESTED_TAGS.map((t) => (
            <Pill key={t} active={tags.includes(t)} onClick={() => toggleTag(t)} className="px-3 py-1 text-xs">
              #{t}
            </Pill>
          ))}
        </div>
      </div>

      <section className="mt-6">
        <SectionTitle
          action={
            (query || tags.length > 0) && (
              <button
                type="button"
                className="text-sm font-semibold text-primary hover:underline"
                onClick={() => {
                  setQuery("");
                  setTags([]);
                }}
              >
                Reset
              </button>
            )
          }
        >
          {results.length} {results.length === 1 ? "result" : "results"}
        </SectionTitle>
        {results.length === 0 ? (
          <div className="surface rounded-2xl p-8 text-center">
            <p className="font-display text-sm font-semibold">Nothing found</p>
            <p className="mt-1 text-sm text-muted-foreground">Try another name or remove a tag.</p>
          </div>
        ) : (
          <ul className="grid gap-2.5 md:grid-cols-2">
            {results.map((g) => (
              <GameRow key={g.id} game={g} />
            ))}
          </ul>
        )}
      </section>
    </PageShell>
  );
}
