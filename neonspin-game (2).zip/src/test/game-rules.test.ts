import { describe, expect, it } from "vitest";
import { GAMES, countByCategory, gamesForHomeTab, gamesForLobbyFilter, searchGames } from "@/lib/games";
import { canSpin, evaluateSpin, stepBet, type Grid } from "@/lib/slot";

const line = (a: Grid[0][1], b: Grid[0][1], c: Grid[0][1]): Grid => [
  ["🍋", a, "🔔"],
  ["🍋", b, "🔔"],
  ["🍋", c, "🔔"],
];

describe("slot payouts", () => {
  it("pays bet x 25 for three sevens on the win line", () => {
    expect(evaluateSpin(line("7️⃣", "7️⃣", "7️⃣"), 50)).toBe(1250);
  });
  it("returns the bet for two cherries from the left", () => {
    expect(evaluateSpin(line("🍒", "🍒", "💎"), 100)).toBe(100);
  });
  it("pays nothing for a mixed line", () => {
    expect(evaluateSpin(line("🍋", "💎", "⭐"), 100)).toBe(0);
  });
  it("blocks spins the balance cannot cover", () => {
    expect(canSpin(40, 50)).toBe(false);
    expect(canSpin(50, 50)).toBe(true);
  });
  it("keeps bets within 10 and 500", () => {
    expect(stepBet(10, -1)).toBe(10);
    expect(stepBet(500, 1)).toBe(500);
    expect(stepBet(50, 1)).toBe(100);
  });
});

describe("game filtering", () => {
  it("search matches tags case-insensitively", () => {
    expect(searchGames(GAMES, "megaways").map((g) => g.id)).toEqual(["crystal-dragon", "galaxy-jackpot"]);
  });
  it("selected tags must all match", () => {
    expect(searchGames(GAMES, "", ["Cards", "Live Dealer"]).map((g) => g.id)).toEqual(["vip-blackjack"]);
  });
  it("Live tab and filter only show live games", () => {
    expect(gamesForHomeTab(GAMES, "Live").every((g) => g.isLive)).toBe(true);
    expect(gamesForLobbyFilter(GAMES, "Live").length).toBe(4);
  });
  it("category tiles count games per category", () => {
    expect(countByCategory(GAMES, "Slots")).toBe(4);
  });
});
